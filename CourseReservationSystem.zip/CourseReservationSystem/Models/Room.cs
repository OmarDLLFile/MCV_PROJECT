﻿namespace CourseReservationSystem.Models
{
    public class Room
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int BuildingId { get; set; }
        public int? Capacity { get; set; }

        public Building? Building { get; set; }

        // ✅ Navigation property
        public ICollection<Course> Courses { get; set; } = new List<Course>();
    }
}
