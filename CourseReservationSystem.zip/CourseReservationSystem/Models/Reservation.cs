﻿
namespace CourseReservationSystem.Models
{
    public class Reservation
    {
        public int Id { get; set; }

        public int UserId { get; set; }
        public int CourseId { get; set; }

        public string Status { get; set; } = "pending"; // "pending", "accepted", "rejected"
        public DateTime RequestDate { get; set; } = DateTime.UtcNow;

        public User? User { get; set; }
        public Course? Course { get; set; }
    }
}
