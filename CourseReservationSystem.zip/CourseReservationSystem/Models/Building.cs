﻿namespace CourseReservationSystem.Models
{
    public class Building
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Address { get; set; }

        // ✅ Navigation property
        public ICollection<Room> Rooms { get; set; } = new List<Room>();
        public ICollection<Course> Courses { get; set; } = new List<Course>();
    }
}
