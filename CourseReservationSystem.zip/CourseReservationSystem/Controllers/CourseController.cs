﻿//using CourseReservationSystem.Data;
//using CourseReservationSystem.Models;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;

//namespace CourseReservationSystem.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class CourseController : ControllerBase
//    {
//        private readonly ApplicationDbContext _context;

//        public CourseController(ApplicationDbContext context)
//        {
//            _context = context;
//        }

//        // GET: api/Course
//        // Public - anyone can view available courses
//        [HttpGet]
//        [AllowAnonymous]
//        public async Task<ActionResult<IEnumerable<Course>>> GetCourses()
//        {
//            return await _context.Courses
//                .Include(c => c.Department)
//                .Include(c => c.Building)
//                .Include(c => c.Room)
//                .ToListAsync();
//        }

//        // GET: api/Course/5
//        // Public - course details by ID
//        [HttpGet("{id}")]
//        [AllowAnonymous]
//        public async Task<ActionResult<Course>> GetCourse(int id)
//        {
//            var course = await _context.Courses
//                .Include(c => c.Department)
//                .Include(c => c.Building)
//                .Include(c => c.Room)
//                .FirstOrDefaultAsync(c => c.Id == id);

//            if (course == null)
//                return NotFound();

//            return course;
//        }

//        // POST: api/Course
//        // Admin only - create new course
//        [HttpPost]
//        [Authorize(Roles = "Admin")]
//        public async Task<ActionResult<Course>> PostCourse(Course course)
//        {
//            _context.Courses.Add(course);
//            await _context.SaveChangesAsync();

//            var createdCourse = await _context.Courses
//                .Include(c => c.Department)
//                .Include(c => c.Building)
//                .Include(c => c.Room)
//                .FirstOrDefaultAsync(c => c.Id == course.Id);

//            return CreatedAtAction(nameof(GetCourse), new { id = course.Id }, createdCourse);
//        }


//        // PUT: api/Course/5
//        // Admin only - update course by ID
//        [HttpPut("{id}")]
//        [Authorize(Roles = "Admin")]
//        public async Task<IActionResult> PutCourse(int id, Course course)
//        {
//            if (id != course.Id)
//                return BadRequest();

//            _context.Entry(course).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!_context.Courses.Any(c => c.Id == id))
//                    return NotFound();

//                throw;
//            }

//            return NoContent();
//        }

//        // DELETE: api/Course/5
//        // Admin only - delete course
//        [HttpDelete("{id}")]
//        [Authorize(Roles = "Admin")]
//        public async Task<IActionResult> DeleteCourse(int id)
//        {
//            var course = await _context.Courses.FindAsync(id);
//            if (course == null)
//                return NotFound();

//            _context.Courses.Remove(course);
//            await _context.SaveChangesAsync();

//            return NoContent();
//        }
//    }
//}


// ======================================================================



using CourseReservationSystem.Data;
using CourseReservationSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CourseReservationSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CourseController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Course
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult<IEnumerable<object>>> GetCourses()
        {
            try
            {
                var courses = await _context.Courses
                    .Include(c => c.Department)
                    .Include(c => c.Building)
                    .Include(c => c.Room)
                    .Select(c => new
                    {
                        c.Id,
                        c.Title,
                        c.Description,
                        c.Date,
                        c.DepartmentId,
                        c.BuildingId,
                        c.RoomId,
                        Department = c.Department != null ? new { c.Department.Id, c.Department.Name } : null,
                        Building = c.Building != null ? new { c.Building.Id, c.Building.Name } : null,
                        Room = c.Room != null ? new { c.Room.Id, c.Room.Name, c.Room.Capacity } : null
                    })
                    .ToListAsync();

                return Ok(courses);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/Course/5
        [HttpGet("{id}")]
        [AllowAnonymous]
        public async Task<ActionResult<object>> GetCourse(int id)
        {
            try
            {
                var course = await _context.Courses
                    .Include(c => c.Department)
                    .Include(c => c.Building)
                    .Include(c => c.Room)
                    .Where(c => c.Id == id)
                    .Select(c => new
                    {
                        c.Id,
                        c.Title,
                        c.Description,
                        c.Date,
                        c.DepartmentId,
                        c.BuildingId,
                        c.RoomId,
                        Department = c.Department != null ? new { c.Department.Id, c.Department.Name } : null,
                        Building = c.Building != null ? new { c.Building.Id, c.Building.Name } : null,
                        Room = c.Room != null ? new { c.Room.Id, c.Room.Name, c.Room.Capacity } : null
                    })
                    .FirstOrDefaultAsync();

                if (course == null)
                    return NotFound();

                return Ok(course);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // POST: api/Course
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Course>> PostCourse(Course course)
        {
            try
            {
                _context.Courses.Add(course);
                await _context.SaveChangesAsync();

                var createdCourse = await _context.Courses
                    .Include(c => c.Department)
                    .Include(c => c.Building)
                    .Include(c => c.Room)
                    .FirstOrDefaultAsync(c => c.Id == course.Id);

                return CreatedAtAction(nameof(GetCourse), new { id = course.Id }, createdCourse);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // PUT: api/Course/5
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PutCourse(int id, Course course)
        {
            if (id != course.Id)
                return BadRequest();

            _context.Entry(course).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Courses.Any(c => c.Id == id))
                    return NotFound();
                throw;
            }

            return NoContent();
        }

        // DELETE: api/Course/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteCourse(int id)
        {
            var course = await _context.Courses.FindAsync(id);
            if (course == null)
                return NotFound();

            _context.Courses.Remove(course);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}