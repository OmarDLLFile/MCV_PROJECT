﻿//using CourseReservationSystem.Data;
//using CourseReservationSystem.Models;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using System.Security.Claims;

//namespace CourseReservationSystem.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ReservationController : ControllerBase
//    {
//        private readonly ApplicationDbContext _context;

//        public ReservationController(ApplicationDbContext context)
//        {
//            _context = context;
//        }

//        // POST: api/Reservation
//        // User only - request a course reservation
//        [HttpPost]
//        [Authorize(Roles = "User")]
//        public async Task<ActionResult<Reservation>> ReserveCourse([FromBody] int courseId)
//        {
//            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

//            var reservation = new Reservation
//            {
//                UserId = userId,
//                CourseId = courseId,
//                Status = "pending",
//                RequestDate = DateTime.UtcNow
//            };

//            _context.Reservations.Add(reservation);
//            await _context.SaveChangesAsync();

//            return Ok(reservation);
//        }

//        // GET: api/Reservation/pending
//        // Admin only - view all pending reservations
//        [HttpGet("pending")]
//        [Authorize(Roles = "Admin")]
//        public async Task<ActionResult<IEnumerable<Reservation>>> GetPendingReservations()
//        {
//            return await _context.Reservations
//                .Where(r => r.Status == "pending")
//                .Include(r => r.Course)
//                .Include(r => r.User)
//                .ToListAsync();
//        }

//        // PUT: api/Reservation/{id}?status=accepted
//        // Admin only - approve or reject a reservation
//        [HttpPut("{id}")]
//        [Authorize(Roles = "Admin")]
//        public async Task<IActionResult> UpdateReservationStatus(int id, [FromQuery] string status)
//        {
//            var reservation = await _context.Reservations.FindAsync(id);
//            if (reservation == null)
//                return NotFound();

//            if (status != "accepted" && status != "rejected")
//                return BadRequest("Invalid status");

//            reservation.Status = status;
//            await _context.SaveChangesAsync();

//            return NoContent();
//        }

//        // GET: api/Reservation/my
//        // User only - view own approved reservations
//        [HttpGet("my")]
//        [Authorize(Roles = "User")]
//        public async Task<ActionResult<IEnumerable<Reservation>>> GetMyApprovedReservations()
//        {
//            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

//            return await _context.Reservations
//                .Where(r => r.UserId == userId && r.Status == "accepted")
//                .Include(r => r.Course)
//                .ToListAsync();
//        }
//    }
//}


// =========================================


using CourseReservationSystem.Data;
using CourseReservationSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace CourseReservationSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ReservationController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: api/Reservation
        // User only - request a course reservation
        [HttpPost]
        [Authorize(Roles = "User")]
        public async Task<ActionResult<Reservation>> ReserveCourse([FromBody] int courseId)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            var reservation = new Reservation
            {
                UserId = userId,
                CourseId = courseId,
                Status = "pending",
                RequestDate = DateTime.UtcNow
            };

            _context.Reservations.Add(reservation);
            await _context.SaveChangesAsync();

            return Ok(reservation);
        }

        // GET: api/Reservation/pending
        // Admin only - view all pending reservations
        [HttpGet("pending")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<IEnumerable<Reservation>>> GetPendingReservations()
        {
            return await _context.Reservations
                .Where(r => r.Status == "pending")
                .Include(r => r.Course)
                .Include(r => r.User)
                .ToListAsync();
        }

        // PUT: api/Reservation/{id}?status=accepted
        // Admin only - approve or reject a reservation
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateReservationStatus(int id, [FromQuery] string status)
        {
            var reservation = await _context.Reservations.FindAsync(id);
            if (reservation == null)
                return NotFound();

            if (status != "accepted" && status != "rejected")
                return BadRequest("Invalid status");

            reservation.Status = status;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //// GET: api/Reservation/my
        //// User only - view own approved reservations
        //[HttpGet("my")]
        //[Authorize(Roles = "User")]
        //public async Task<ActionResult<IEnumerable<Course>>> GetMyApprovedCourses()
        //{
        //    var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

        //    var courses = await _context.Reservations
        //        .Where(r => r.UserId == userId && r.Status == "accepted")
        //        .Include(r => r.Course)
        //            .ThenInclude(c => c.Department)
        //        .Include(r => r.Course)
        //            .ThenInclude(c => c.Room)
        //        .Include(r => r.Course)
        //            .ThenInclude(c => c.Building)
        //        .Select(r => r.Course)
        //        .ToListAsync();

        //    return Ok(courses);
        //}


        //============== get user courses =======================

        // GET: api/Reservation/UserCourses
        // User only - view own accepted courses
        [HttpGet("UserCourses")]
        [Authorize(Roles = "User,Admin")]
        public async Task<ActionResult<IEnumerable<Course>>> GetUserCourses()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");

            var courses = await _context.Reservations
                .Where(r => r.UserId == userId && r.Status == "accepted")
                .Include(r => r.Course)
                    .ThenInclude(c => c.Department)
                .Include(r => r.Course)
                    .ThenInclude(c => c.Building)
                .Include(r => r.Course)
                    .ThenInclude(c => c.Room)
                .Select(r => r.Course)
                .ToListAsync();

            return Ok(courses);
        }

    }
}
