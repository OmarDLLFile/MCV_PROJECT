﻿////using CourseReservationSystem.Models;
////using Microsoft.AspNetCore.Authorization;
////using Microsoft.AspNetCore.Identity;
////using Microsoft.AspNetCore.Mvc;
////using Microsoft.EntityFrameworkCore;

////namespace CourseReservationSystem.Controllers
////{
////    [Route("api/[controller]")]
////    [ApiController]
////    [Authorize(Roles = "Admin")]
////    public class UserController : ControllerBase
////    {
////        private readonly UserManager<ApplicationUser> _userManager;

////        public UserController(UserManager<ApplicationUser> userManager)
////        {
////            _userManager = userManager;
////        }

////        // GET: api/User
////        [HttpGet]
////        public async Task<ActionResult<IEnumerable<object>>> GetUsers()
////        {
////            var users = await _userManager.Users.ToListAsync();

////            // Return only relevant user data (avoid exposing sensitive info)
////            var result = users.Select(u => new
////            {
////                u.Id,
////                u.UserName,
////                u.Email
////            });

////            return Ok(result);
////        }

////        // GET: api/User/{id}
////        [HttpGet("{id}")]
////        public async Task<ActionResult<object>> GetUser(string id)
////        {
////            var user = await _userManager.FindByIdAsync(id);

////            if (user == null)
////                return NotFound();

////            return Ok(new
////            {
////                user.Id,
////                user.UserName,
////                user.Email
////            });
////        }

////        // PUT: api/User/{id}
////        [HttpPut("{id}")]
////        public async Task<IActionResult> UpdateUser(string id, [FromBody] ApplicationUser updatedUser)
////        {
////            var user = await _userManager.FindByIdAsync(id);
////            if (user == null)
////                return NotFound();

////            user.UserName = updatedUser.UserName;
////            user.Email = updatedUser.Email;

////            var result = await _userManager.UpdateAsync(user);
////            if (result.Succeeded)
////                return NoContent();

////            return BadRequest(result.Errors);
////        }

////        // DELETE: api/User/{id}
////        [HttpDelete("{id}")]
////        public async Task<IActionResult> DeleteUser(string id)
////        {
////            var user = await _userManager.FindByIdAsync(id);
////            if (user == null)
////                return NotFound();

////            var result = await _userManager.DeleteAsync(user);
////            if (result.Succeeded)
////                return NoContent();

////            return BadRequest(result.Errors);
////        }
////    }
////}


//// =========================================================================

//using CourseReservationSystem.Models;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Identity;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;

//namespace CourseReservationSystem.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class UserController : ControllerBase
//    {
//        private readonly UserManager<IdentityUser> _userManager;
//        private readonly RoleManager<IdentityRole> _roleManager;

//        public UserController(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
//        {
//            _userManager = userManager;
//            _roleManager = roleManager;
//        }

//        // GET: api/User
//        [HttpGet]
//        public async Task<ActionResult<IEnumerable<object>>> GetUsers()
//        {
//            var users = await _userManager.Users.ToListAsync();
//            var result = new List<object>();

//            foreach (var user in users)
//            {
//                var roles = await _userManager.GetRolesAsync(user);
//                result.Add(new
//                {
//                    user.Id,
//                    user.UserName,
//                    user.Email,
//                    Role = roles.FirstOrDefault() ?? "User"
//                });
//            }

//            return Ok(result);
//        }

//        // GET: api/User/{id}
//        [HttpGet("{id}")]
//        public async Task<ActionResult<object>> GetUser(string id)
//        {
//            var user = await _userManager.FindByIdAsync(id);
//            if (user == null)
//                return NotFound();

//            var roles = await _userManager.GetRolesAsync(user);

//            return Ok(new
//            {
//                user.Id,
//                user.UserName,
//                user.Email,
//                Role = roles.FirstOrDefault() ?? "User"
//            });
//        }

//        // PUT: api/User/{id}
//        [HttpPut("{id}")]
//        public async Task<IActionResult> UpdateUser(string id, [FromBody] UpdateUserDto updatedUser)
//        {
//            var user = await _userManager.FindByIdAsync(id);
//            if (user == null)
//                return NotFound();

//            user.UserName = updatedUser.UserName;
//            user.Email = updatedUser.Email;

//            // Update user info
//            var result = await _userManager.UpdateAsync(user);
//            if (!result.Succeeded)
//                return BadRequest(result.Errors);

//            // Update Role if changed
//            var currentRoles = await _userManager.GetRolesAsync(user);
//            var currentRole = currentRoles.FirstOrDefault();
//            if (currentRole != updatedUser.Role)
//            {
//                if (currentRole != null)
//                    await _userManager.RemoveFromRoleAsync(user, currentRole);

//                if (!await _roleManager.RoleExistsAsync(updatedUser.Role))
//                    await _roleManager.CreateAsync(new IdentityRole(updatedUser.Role));

//                await _userManager.AddToRoleAsync(user, updatedUser.Role);
//            }

//            return NoContent();
//        }

//        // DELETE: api/User/{id}
//        [HttpDelete("{id}")]
//        public async Task<IActionResult> DeleteUser(string id)
//        {
//            var user = await _userManager.FindByIdAsync(id);
//            if (user == null)
//                return NotFound();

//            var result = await _userManager.DeleteAsync(user);
//            if (!result.Succeeded)
//                return BadRequest(result.Errors);

//            return NoContent();
//        }
//    }

//    // DTO for updating user
//    public class UpdateUserDto
//    {
//        public string FullName { get; set; } = string.Empty;
//        public string UserName { get; set; } = string.Empty;
//        public string Email { get; set; } = string.Empty;
//        public string Role { get; set; } = "User";
//    }
//}


// ==================================================================


using CourseReservationSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CourseReservationSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public UserController(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        // GET: api/User
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetUsers()
        {
            var users = await _userManager.Users.ToListAsync();
            var result = new List<object>();

            foreach (var user in users)
            {
                // Console.WriteLine(user);
                var roles = await _userManager.GetRolesAsync(user);
                result.Add(new
                {
                    user.Id,
                    user.UserName,
                    user.Email,
                    Role = roles.FirstOrDefault() ?? "User"
                });
            }

            return Ok(result);
        }

        // GET: api/User/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetUser(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
                return NotFound();

            var roles = await _userManager.GetRolesAsync(user);

            return Ok(new
            {
                user.Id,
                user.UserName,
                user.Email,
                Role = roles.FirstOrDefault() ?? "User"
            });
        }

        // PUT: api/User/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(string id, [FromBody] UpdateUserDto updatedUser)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
                return NotFound();

            user.UserName = updatedUser.UserName;
            user.Email = updatedUser.Email;

            // Update user info
            var result = await _userManager.UpdateAsync(user);
            if (!result.Succeeded)
                return BadRequest(result.Errors);

            // Update Role if changed
            var currentRoles = await _userManager.GetRolesAsync(user);
            var currentRole = currentRoles.FirstOrDefault();
            if (currentRole != updatedUser.Role)
            {
                if (currentRole != null)
                    await _userManager.RemoveFromRoleAsync(user, currentRole);

                if (!await _roleManager.RoleExistsAsync(updatedUser.Role))
                    await _roleManager.CreateAsync(new IdentityRole(updatedUser.Role));

                await _userManager.AddToRoleAsync(user, updatedUser.Role);
            }

            return NoContent();
        }

        // DELETE: api/User/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
                return NotFound();

            var result = await _userManager.DeleteAsync(user);
            if (!result.Succeeded)
                return BadRequest(result.Errors);

            return NoContent();
        }
    }

    // DTO for updating user
    public class UpdateUserDto
    {
        public string FullName { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = "User";
    }
}