﻿$(document).ready(function () {
    const token = localStorage.getItem("token");
    const $tbody = $('#users-table-body');

    // Animation for sidebar
    $('#main-content').addClass('fade-in');
    $('.sidebar .nav-link').on('click', function (e) {
        const link = $(this).attr('href');
        if (link && link !== window.location.pathname.split('/').pop()) {
            e.preventDefault();
            $('#main-content').removeClass('fade-in').addClass('fade-out');
            setTimeout(() => {
                window.location.href = link;
            }, 500);
        }
    });

    // ✅ Fetch and display real user data
    async function fetchUsers() {
        try {
            const response = await fetch("https://localhost:7005/api/User", {
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });

            if (!response.ok) throw new Error("Failed to fetch users");

            // const users = await response.json();
            const raw = await response.json();
            const users = raw.$values || [];

            console.log(users);


            $tbody.empty(); // clear old rows
            users.forEach((user, idx) => {
                $tbody.append(`
                    <tr>
                        <th scope="row">${idx + 1}</th>
                        <td>${user.fullName || user.userName}</td>
                        <td>${user.email}</td>
                        <td>${user.role}</td>
                    </tr>
                `);
            });

        } catch (error) {
            console.error("Error fetching users:", error);
            $tbody.html('<tr><td colspan="4" class="text-danger">Failed to load users.</td></tr>');
        }
    }

    fetchUsers(); // Call it on page load
});