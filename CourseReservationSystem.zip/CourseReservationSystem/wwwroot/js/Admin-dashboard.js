let departments = [];
let buildings = [];
let rooms = [];
let courses = [];
let reservations = [];
let nextId = 1;


document.addEventListener('DOMContentLoaded', function () {
    // Add some sample data if arrays are empty
    if (departments.length === 0) {
        departments = [
            { id: 1, name: "Computer Science", description: "Department of Computer Science" },
            { id: 2, name: "Mathematics", description: "Department of Mathematics" }
        ];
        nextId = 3;
    }
    
    if (buildings.length === 0) {
        buildings = [
            { id: 1, name: "Science Building", address: "123 Science St" },
            { id: 2, name: "Main Building", address: "456 University Ave" }
        ];
        nextId = Math.max(nextId, 3);
    }
    
    if (rooms.length === 0) {
        rooms = [
            { id: 1, name: "Room 101", buildingId: 1, capacity: 30 },
            { id: 2, name: "Room 201", buildingId: 1, capacity: 50 },
            { id: 3, name: "Auditorium A", buildingId: 2, capacity: 200 }
        ];
        nextId = Math.max(nextId, 4);
    }
    
    if (courses.length === 0) {
        courses = [
            { 
                id: 1, 
                title: "Introduction to Programming", 
                description: "Basic programming concepts", 
                departmentId: 1, 
                buildingId: 1, 
                roomId: 1, 
                date: "2023-06-15T10:00" 
            },
            { 
                id: 2, 
                title: "Calculus I", 
                description: "Introduction to calculus", 
                departmentId: 2, 
                buildingId: 2, 
                roomId: 3, 
                date: "2023-06-16T14:00" 
            }
        ];
        nextId = Math.max(nextId, 3);
    }
    
    if (reservations.length === 0) {
        reservations = [
            { 
                id: 1, 
                title: "Faculty Meeting", 
                description: "Monthly faculty meeting", 
                date: "2023-06-20T15:00" 
            }
        ];
        nextId = Math.max(nextId, 2);
    }

    const addCourseBtn = document.getElementById('addCourseBtn');
    const addCourseModal = new bootstrap.Modal(document.getElementById('addCourseModal'));
    const departmentSelect = document.getElementById('departmentId');
    const buildingSelect = document.getElementById('buildingId');
    const roomSelect = document.getElementById('roomId');

    addCourseBtn.addEventListener('click', function () {
        addCourseModal.show();
        fetchDropdowns();
    });

    function fetchDropdowns() {
        fetch('/api/Department')
            .then(res => res.json())
            .then(data => {
                departmentSelect.innerHTML = data.map(d => `<option value="${d.id}">${d.name}</option>`).join('');
            });

        fetch('/api/Building')
            .then(res => res.json())
            .then(data => {
                buildingSelect.innerHTML = data.map(b => `<option value="${b.id}">${b.name}</option>`).join('');
            });

        fetch('/api/Room')
            .then(res => res.json())
            .then(data => {
                roomSelect.innerHTML = data.map(r => `<option value="${r.id}">${r.name}</option>`).join('');
            });
    }

    document.getElementById('addCourseForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const course = {
            name: document.getElementById('courseName').value,
            departmentId: departmentSelect.value,
            buildingId: buildingSelect.value,
            roomId: roomSelect.value
        };
        fetch('/api/Course', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                // Add Authorization header if needed
            },
            body: JSON.stringify(course)
        })
        .then(res => {
            if (res.ok) {
                addCourseModal.hide();
                alert('Course added successfully!');
                // Optionally refresh course list
            } else {
                alert('Failed to add course.');
            }
        });
    });
});
