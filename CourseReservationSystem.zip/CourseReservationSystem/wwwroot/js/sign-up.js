document.addEventListener('DOMContentLoaded', function () {
    const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const strengthFill = document.getElementById('strengthFill');
    const strengthText = document.getElementById('strengthText');

    function checkPasswordStrength(password) {
        let strength = 0;
        let text = 'Weak';

        if (password.length >= 8) strength++;
        if (password.match(/[a-z]/)) strength++;
        if (password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^a-zA-Z0-9]/)) strength++;

        strengthFill.className = 'strength-fill';

        if (strength <= 2) {
            strengthFill.classList.add('strength-weak');
            text = 'Weak';
        } else if (strength <= 4) {
            strengthFill.classList.add('strength-medium');
            text = 'Medium';
        } else {
            strengthFill.classList.add('strength-strong');
            text = 'Strong';
        }

        strengthText.textContent = text;
    }

    passwordInput.addEventListener('input', function () {
        checkPasswordStrength(this.value);
    });

    confirmPasswordInput.addEventListener('input', function () {
        if (this.value !== passwordInput.value) {
            this.style.borderColor = 'rgba(239, 68, 68, 0.5)';
        } else {
            this.style.borderColor = 'rgba(16, 185, 129, 0.5)';
        }
    });

    inputs.forEach(input => {
        input.addEventListener('focus', function () {
            this.parentElement.style.transform = 'scale(1.02)';
            this.parentElement.style.transition = 'transform 0.3s ease';
        });

        input.addEventListener('blur', function () {
            this.parentElement.style.transform = 'scale(1)';
        });

        input.addEventListener('input', function () {
            if (this.value.length > 0) {
                this.style.background = 'rgba(255, 255, 255, 0.15)';
                this.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
            } else {
                this.style.background = 'rgba(255, 255, 255, 0.1)';
                this.style.boxShadow = 'none';
            }
        });
    });

    const particlesContainer = document.querySelector('.floating-particles');

    setInterval(() => {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.width = Math.random() * 8 + 4 + 'px';
        particle.style.height = particle.style.width;
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 6 + 's';

        particlesContainer.appendChild(particle);

        setTimeout(() => {
            if (particle.parentNode) {
                particle.parentNode.removeChild(particle);
            }
        }, 6000);
    }, 3000);
});


// ====================== Submit Form to API ======================

document.getElementById("signupForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const name = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const terms = document.getElementById("terms").checked;

    if (!name || !email || !password || !confirmPassword) {
        alert('Please fill in all fields');
        return;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return;
    }

    if (!terms) {
        alert("Please agree to the Terms of Service and Privacy Policy");
        return;
    }

    const user = {
        name: name,
        email: email,
        passwordHash: password,
        role: "User"
    };

    try {
        const response = await fetch("https://localhost:7005/api/Auth/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(user)
        });

        if (response.ok) {
            alert("Registration successful! Redirecting to login...");
            window.location.href = "login-page.html";
        } else {
            const error = await response.text();
            alert("Error: " + error);
        }
    } catch (err) {
        console.error(err);
        alert("Something went wrong.");
    }
});
