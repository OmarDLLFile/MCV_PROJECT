document.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');
    const userName = localStorage.getItem('userName');
    const userRole = localStorage.getItem('userRole');

    //if (UserRole === "Admin") {
    //    window.location.href = "Aadmin-dashboard.html";
    //    return;
    //}

    const courseList = document.getElementById('courseList');
    const filterInput = document.getElementById('filterInput');
    const userNamePlaceholder = document.getElementById('userNamePlaceholder');

    if (userNamePlaceholder && userName) {
        userNamePlaceholder.textContent = userName;
    }

    document.getElementById('logoutBtn').addEventListener('click', () => {
        localStorage.clear();
        window.location.href = "login-page.html";
    });

    // Show buttons by role
    if (userRole === "Admin") {
        document.getElementById("addCourseBtn").style.display = "inline-block";
    } else if (userRole === "User") {
        document.getElementById("reserveCourseBtn").style.display = "inline-block";
    }

    // ======================= Fetch Courses =======================
    async function fetchCourses() {
        try {
            const res = await fetch("https://localhost:7005/api/Reservation/UserCourses", {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

            const result = await res.json();
            const courses = result.$values || result;

            if (!Array.isArray(courses)) {
                console.error("Expected array but got:", result);
                return;
            }

            displayCourses(courses);
        } catch (err) {
            console.error("Failed to load courses:", err);
            courseList.innerHTML = `<p style="color:red">Failed to load courses.</p>`;
        }
    }

    function displayCourses(courses) {
        courseList.innerHTML = "";

        if (courses.length === 0) {
            courseList.innerHTML = "<p>No courses found.</p>";
            return;
        }

        courses.forEach(course => {
            const item = document.createElement('div');
            item.className = "course-item";

            item.innerHTML = `
                <div class="course-content">
                    <h3 class="course-title">${course.title}</h3>
                    <p class="course-description">${course.description}</p>
                    <div class="course-details">
                        <span class="detail-item">${course.department?.name || "N/A"}</span>
                        <span class="detail-separator">•</span>
                        <span class="detail-item">${course.building?.name || "N/A"}</span>
                        <span class="detail-separator">•</span>
                        <span class="detail-item">${course.room?.name || "N/A"}</span>
                        <span class="detail-separator">•</span>
                        <span class="detail-item">${new Date(course.date).toLocaleString()}</span>
                    </div>
                </div>
            `;

            courseList.appendChild(item);
        });
    }

    // ========== Filter Input ==========
    filterInput.addEventListener('input', function () {
        const keyword = this.value.toLowerCase();
        const items = document.querySelectorAll(".course-item");

        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(keyword) ? 'block' : 'none';
        });
    });

    // ========== Admin Only: Add Course ==========
    document.getElementById('addCourseBtn').addEventListener('click', async function () {
        const title = prompt("Enter course title:");
        const description = prompt("Enter course description:");
        const departmentId = prompt("Enter department ID:");
        const buildingId = prompt("Enter building ID:");
        const roomId = prompt("Enter room ID:");
        const date = prompt("Enter course date (YYYY-MM-DDTHH:MM:SS):");

        if (!title || !description || !departmentId || !buildingId || !roomId || !date) {
            alert("All fields are required!");
            return;
        }

        try {
            const res = await fetch("https://localhost:7005/api/Course", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({
                    title,
                    description,
                    departmentId: parseInt(departmentId),
                    buildingId: parseInt(buildingId),
                    roomId: parseInt(roomId),
                    date
                })
            });

            if (res.ok) {
                alert("Course added successfully.");
                fetchCourses();
            } else {
                const error = await res.text();
                alert("Error: " + error);
            }
        } catch (err) {
            console.error(err);
            alert("Failed to add course.");
        }
    });

    // ========== User Only: Reserve Course ==========
    const popup = document.getElementById("reservationPopup");
    const confirmBtn = document.getElementById("confirmReservation");
    const closeBtn = document.getElementById("closePopup");
    const reserveBtn = document.getElementById("reserveCourseBtn");

    reserveBtn?.addEventListener('click', () => {
        popup.style.display = 'flex';
    });

    closeBtn?.addEventListener('click', () => {
        popup.style.display = 'none';
    });

    confirmBtn?.addEventListener('click', async () => {
        const courseId = parseInt(document.getElementById("reserveCourseId").value);
        if (!courseId) {
            alert("Please enter a valid course ID.");
            return;
        }

        try {
            const res = await fetch("https://localhost:7005/api/Reservation", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify(courseId)
            });

            if (res.ok) {
                alert("Reservation submitted successfully.");
                popup.style.display = 'none';
                fetchCourses();
            } else {
                const error = await res.text();
                alert("Reservation failed: " + error);
            }
        } catch (err) {
            console.error(err);
            alert("Error reserving course.");
        }
    });

    if (UserRole === "User") {
        fetchCourses();
    }

});
