﻿$(document).ready(function () {
    // Fade-in animation on page load
    $('#main-content').addClass('fade-in');

    // Sidebar navigation animation
    $('.sidebar .nav-link').on('click', function (e) {
        var link = $(this).attr('href');
        if (link && link !== window.location.pathname.split('/').pop()) {
            e.preventDefault();
            $('#main-content').removeClass('fade-in').addClass('fade-out');
            setTimeout(function () {
                window.location.href = link;
            }, 500);
        }
    });
});