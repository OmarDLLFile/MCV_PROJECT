//document.addEventListener('DOMContentLoaded', function () {
//    const loginButton = document.querySelector('.login-button');
//    const inputs = document.querySelectorAll('input[type="email"], input[type="password"]');

//    loginButton.addEventListener('click', async function (e) {
//        e.preventDefault();

//        const email = document.getElementById('email').value;
//        const password = document.getElementById('password').value;

//        if (!email || !password) {
//            alert('Please enter email and password');
//            return;
//        }

//        loginButton.innerHTML = 'Logging in...';
//        loginButton.disabled = true;

//        try {
//            const response = await fetch('https://localhost:7005/api/Auth/login', {
//                method: 'POST',
//                headers: {
//                    'Content-Type': 'application/json'
//                },
//                body: JSON.stringify({
//                    email: email,
//                    password: password
//                })
//            });

//            if (response.ok) {
//                const data = await response.json();

//                // Store token and user info in localStorage
//                localStorage.setItem('token', data.token);
//                localStorage.setItem('userName', data.name);
//                localStorage.setItem('userEmail', data.email);
//                localStorage.setItem('userRole', data.role);

//                alert('Login successful! Redirecting...');
//                window.location.href = 'User-Dashboard.html'; // or whatever page you want to go to
//            } else {
//                const error = await response.text();
//                alert('Login failed: ' + error);
//            }
//        } catch (error) {
//            console.error(error);
//            alert('An error occurred. Please try again.');
//        }

//        loginButton.innerHTML = 'Login';
//        loginButton.disabled = false;
//    });

//    inputs.forEach(input => {
//        input.addEventListener('focus', function () {
//            this.parentElement.style.transform = 'scale(1.02)';
//            this.parentElement.style.transition = 'transform 0.3s ease';
//        });

//        input.addEventListener('blur', function () {
//            this.parentElement.style.transform = 'scale(1)';
//        });

//        input.addEventListener('input', function () {
//            if (this.value.length > 0) {
//                this.style.background = 'rgba(255, 255, 255, 0.15)';
//                this.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
//            } else {
//                this.style.background = 'rgba(255, 255, 255, 0.1)';
//                this.style.boxShadow = 'none';
//            }
//        });
//    });

//    const particlesContainer = document.querySelector('.floating-particles');

//    setInterval(() => {
//        const particle = document.createElement('div');
//        particle.className = 'particle';
//        particle.style.width = Math.random() * 8 + 4 + 'px';
//        particle.style.height = particle.style.width;
//        particle.style.left = Math.random() * 100 + '%';
//        particle.style.top = Math.random() * 100 + '%';
//        particle.style.animationDelay = Math.random() * 6 + 's';

//        particlesContainer.appendChild(particle);

//        setTimeout(() => {
//            if (particle.parentNode) {
//                particle.parentNode.removeChild(particle);
//            }
//        }, 6000);
//    }, 3000);
//});

// ============================================================

document.addEventListener('DOMContentLoaded', function () {
    const loginButton = document.querySelector('.login-button');
    const inputs = document.querySelectorAll('input[type="email"], input[type="password"]');

    loginButton.addEventListener('click', async function (e) {
        e.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        if (!email || !password) {
            alert('Please enter email and password');
            return;
        }

        loginButton.innerHTML = 'Logging in...';
        loginButton.disabled = true;

        try {
            const response = await fetch('https://localhost:7005/api/Auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email: email,
                    password: password
                })
            });

            if (response.ok) {
                const data = await response.json();

                // Store token and user info in localStorage
                localStorage.setItem('token', data.token);
                localStorage.setItem('userName', data.name);
                localStorage.setItem('userEmail', data.email);
                localStorage.setItem('userRole', data.role);

                alert('Login successful! Redirecting...');

                // Redirect based on role
                if (data.role === "Admin") {
                    window.location.href = 'admin-dashboard.html';
                } else {
                    window.location.href = 'User-Dashboard.html';
                }
            } else {
                const error = await response.text();
                alert('Login failed: ' + error);
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred. Please try again.');
        }

        loginButton.innerHTML = 'Login';
        loginButton.disabled = false;
    });

    inputs.forEach(input => {
        input.addEventListener('focus', function () {
            this.parentElement.style.transform = 'scale(1.02)';
            this.parentElement.style.transition = 'transform 0.3s ease';
        });

        input.addEventListener('blur', function () {
            this.parentElement.style.transform = 'scale(1)';
        });

        input.addEventListener('input', function () {
            if (this.value.length > 0) {
                this.style.background = 'rgba(255, 255, 255, 0.15)';
                this.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
            } else {
                this.style.background = 'rgba(255, 255, 255, 0.1)';
                this.style.boxShadow = 'none';
            }
        });
    });

    const particlesContainer = document.querySelector('.floating-particles');

    setInterval(() => {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.width = Math.random() * 8 + 4 + 'px';
        particle.style.height = particle.style.width;
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 6 + 's';

        particlesContainer.appendChild(particle);

        setTimeout(() => {
            if (particle.parentNode) {
                particle.parentNode.removeChild(particle);
            }
        }, 6000);
    }, 3000);
});

