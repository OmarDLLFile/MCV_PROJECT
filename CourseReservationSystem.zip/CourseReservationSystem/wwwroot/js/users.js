// Sample user data
const users = [
    { name: 'Alice Johnson', email: 'alice@example.com', role: 'Admin' },
    { name: 'Bob Smith', email: 'bob@example.com', role: 'User' },
    { name: 'Charlie Lee', email: 'charlie@example.com', role: 'User' },
    { name: 'Dana White', email: 'dana@example.com', role: 'Moderator' },
];

$(document).ready(function() {
    const $tbody = $('#users-table-body');
    users.forEach((user, idx) => {
        $tbody.append(`
            <tr>
                <th scope="row">${idx + 1}</th>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>
            </tr>
        `);
    });
}); 