﻿document.addEventListener('DOMContentLoaded', function() {
        updateSelectOptions();
        renderCourses();
            
        document.getElementById('courseBuildingId').addEventListener('change', function() {
            updateRoomOptions(this.value);
        });
});

    $(document).ready(function() {
            // Fade-in animation on page load
            $('#main-content').addClass('fade-in');

            // Sidebar navigation animation
            $('.sidebar .nav-link').on('click', function(e) {
                var link = $(this).attr('href');
                if (link && link !== window.location.pathname.split('/').pop()) {
                    e.preventDefault();
                    $('#main-content').removeClass('fade-in').addClass('fade-out');
                    setTimeout(function() {
                        window.location.href = link;
                    }, 500);
                }
            });
    });


// ===================== fetch courses ==========================

document.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');
    const departmentSelect = document.getElementById('courseDepartmentId');
    const buildingSelect = document.getElementById('courseBuildingId');
    const roomSelect = document.getElementById('courseRoomId');

    // Fetch departments, buildings and rooms from APIs
    async function fetchSelectOptions() {
        try {
            const [deptRes, buildingRes, roomRes] = await Promise.all([
                fetch('https://localhost:7005/api/Department'),
                fetch('https://localhost:7005/api/Building'),
                fetch('https://localhost:7005/api/Room')
            ]);

            const [departments, buildings, rooms] = await Promise.all([
                deptRes.json(),
                buildingRes.json(),
                roomRes.json()
            ]);

            // Fill department select
            departments.forEach(d => {
                departmentSelect.innerHTML += `<option value="${d.id}">${d.name}</option>`;
            });

            // Fill building select
            buildings.forEach(b => {
                buildingSelect.innerHTML += `<option value="${b.id}">${b.name}</option>`;
            });

            // When building changes, update room select
            buildingSelect.addEventListener('change', function () {
                const selectedBuildingId = parseInt(this.value);
                roomSelect.innerHTML = `<option value="">Select Room</option>`;
                const filteredRooms = rooms.filter(r => r.buildingId === selectedBuildingId);
                filteredRooms.forEach(r => {
                    roomSelect.innerHTML += `<option value="${r.id}">${r.name}</option>`;
                });
            });

        } catch (err) {
            console.error('Error loading options:', err);
        }
    }

    // Handle form submission
    document.getElementById('addCourseForm').addEventListener('submit', async function (e) {
        e.preventDefault();

        const title = document.getElementById('courseTitle').value;
        const description = document.getElementById('courseDescription').value;
        const departmentId = parseInt(departmentSelect.value);
        const buildingId = parseInt(buildingSelect.value);
        const roomId = parseInt(roomSelect.value);
        const date = document.getElementById('courseDate').value;

        const course = { title, description, departmentId, buildingId, roomId, date };

        try {
            const res = await fetch("https://localhost:7005/api/Course", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify(course)
            });

            if (res.ok) {
                alert("Course added successfully!");
                document.getElementById('addCourseForm').reset();
                bootstrap.Modal.getInstance(document.getElementById('addCourseModal')).hide();
                // Optional: fetch courses again
            } else {
                const error = await res.text();
                alert("Error adding course: " + error);
            }
        } catch (err) {
            console.error("Failed to add course:", err);
            alert("Failed to add course.");
        }
    });

    fetchSelectOptions();
});
