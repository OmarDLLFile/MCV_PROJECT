﻿document.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');
    const departmentSelect = document.getElementById('courseDepartmentId');
    const buildingSelect = document.getElementById('courseBuildingId');
    const roomSelect = document.getElementById('courseRoomId');
    const coursesContainer = document.getElementById('coursesContainer');

    let rooms = []; // Needed for filtering rooms later

    // Helper to unwrap $values if needed
    function unwrap(data) {
        return Array.isArray(data) ? data : data?.$values || [];
    }

    // ==================== Fetch Dropdown Data ====================
    async function fetchDropdowns() {
        try {
            //const [deptsRes, buildsRes, roomsRes] = await Promise.all([
            //    fetch('https://localhost:7005/api/Department', {
            //        headers: { 'Authorization': `Bearer ${token}` }
            //    }),
            //    fetch('https://localhost:7005/api/Building', {
            //        headers: { 'Authorization': `Bearer ${token}` }
            //    }),
            //    fetch('https://localhost:7005/api/Room', {
            //        headers: { 'Authorization': `Bearer ${token}` }
            //    })
            //]);

            const [deptsRes, buildsRes, roomsRes] = await Promise.all([
                fetch('https://localhost:7005/api/Department', { headers: { 'Authorization': `Bearer ${token}` } }),
                fetch('https://localhost:7005/api/Building', { headers: { 'Authorization': `Bearer ${token}` } }),
                fetch('https://localhost:7005/api/Room', { headers: { 'Authorization': `Bearer ${token}` } })
            ]);

            // Check if all responses are ok
            if (!deptsRes.ok || !buildsRes.ok || !roomsRes.ok) {
                throw new Error("One or more dropdown API calls failed.");
            }


            const [deptsRaw, buildsRaw, roomsRaw] = await Promise.all([
                deptsRes.json(),
                buildsRes.json(),
                roomsRes.json()
            ]);

            const departments = unwrap(deptsRaw);
            const buildings = unwrap(buildsRaw);
            rooms = unwrap(roomsRaw); // Save globally

            // Populate department select
            departmentSelect.innerHTML = '<option value="">Select</option>';
            departments.forEach(d => {
                departmentSelect.innerHTML += `<option value="${d.id}">${d.name}</option>`;
            });

            // Populate building select
            buildingSelect.innerHTML = '<option value="">Select</option>';
            buildings.forEach(b => {
                buildingSelect.innerHTML += `<option value="${b.id}">${b.name}</option>`;
            });

            // Update room select when building changes
            buildingSelect.addEventListener('change', () => {
                const buildingId = parseInt(buildingSelect.value);
                roomSelect.innerHTML = '<option value="">Select</option>';
                const filteredRooms = rooms.filter(r => parseInt(r.buildingId) === buildingId);
                filteredRooms.forEach(r => {
                    roomSelect.innerHTML += `<option value="${r.id}">${r.name}</option>`;
                });
            });

        } catch (error) {
            console.error("Error loading dropdowns:", error);
        }
    }

    // ==================== Fetch & Display Courses ====================
    async function fetchCourses() {
        try {
            const response = await fetch('https://localhost:7005/api/Course', {
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (!response.ok) throw new Error("Failed to fetch courses");
            const data = await response.json();
            renderCourses(unwrap(data));
        } catch (error) {
            console.error("Error fetching courses:", error);
            coursesContainer.innerHTML = '<p class="text-danger">Failed to load courses.</p>';
        }
    }

    function renderCourses(courses) {
        coursesContainer.innerHTML = '';

        if (courses.length === 0) {
            coursesContainer.innerHTML = '<p class="text-muted">No courses available.</p>';
            return;
        }

        courses.forEach(course => {
            const card = document.createElement('div');
            card.className = 'col-md-6 mb-3';
            card.innerHTML = `
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">${course.title || 'N/A'}</h5>
                        <p class="card-text">${course.description || 'N/A'}</p>
                        <p class="card-text text-muted">
                            ${course.department?.name || 'N/A'} · 
                            ${course.building?.name || 'N/A'} · 
                            ${course.room?.name || 'N/A'} · 
                            ${course.date ? new Date(course.date).toLocaleString() : 'Invalid Date'}
                        </p>
                    </div>
                </div>
            `;
            coursesContainer.appendChild(card);
        });
    }

    // ==================== Add Course Handler ====================
    document.getElementById('addCourseForm').addEventListener('submit', async function (e) {
        e.preventDefault();

        const course = {
            title: document.getElementById('courseTitle').value,
            description: document.getElementById('courseDescription').value,
            departmentId: parseInt(departmentSelect.value),
            buildingId: parseInt(buildingSelect.value),
            roomId: parseInt(roomSelect.value),
            date: document.getElementById('courseDate').value
        };

        try {
            const res = await fetch('https://localhost:7005/api/Course', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(course)
            });

            if (res.ok) {
                bootstrap.Modal.getInstance(document.getElementById('addCourseModal')).hide();
                this.reset();
                await fetchCourses();
            } else {
                const error = await res.text();
                console.error("Error adding course:", error);
                alert("Error: " + error);
            }
        } catch (error) {
            console.error("Request failed:", error);
            alert("Request failed. Check console.");
        }
    });

    // ==================== Init ====================
    fetchDropdowns();
    fetchCourses();
});
